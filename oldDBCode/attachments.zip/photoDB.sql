-- Create the countries table
CREATE TABLE countries (
    country_name TEXT PRIMARY KEY
);

-- Create the provinces table
CREATE TABLE provinces (
    country_name TEXT NOT NULL,
    province_name TEXT NOT NULL,
    FOREIGN KEY (country_name) REFERENCES countries(country_name)
    PRIMARY KEY (country_name, province_name)
);

-- Create the cities table
CREATE TABLE cities (
    province_name TEXT NOT NULL,
    city_name TEXT NOT NULL,
    FOREIGN KEY (province_name) REFERENCES provinces(province_name)
    PRIMARY KEY (province_name, city_name)
);

-- Create the photos table
CREATE TABLE photos (
    photo_id INTEGER PRIMARY KEY AUTOINCREMENT,
    city_name TEXT NOT NULL,
    photo_filepath TEXT UNIQUE NOT NULL,
    timestamp DATETIME NOT NULL,
    caption TEXT,
    FOREIGN KEY (city_name) REFERENCES cities(city_name)
);

-- Create the trips table
CREATE TABLE trips (
    trip_id INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_name TEXT NOT NULL,
    trip_date DATE NOT NULL,
    trip_text TEXT
);

-- Create the trip_location table
CREATE TABLE trip_location (
    trip_id INTEGER NOT NULL,
    city_name TEXT NOT NULL,
    PRIMARY KEY (trip_id, city_name),
    FOREIGN KEY (trip_id) REFERENCES trips(trip_id),
    FOREIGN KEY (city_name) REFERENCES cities(city_name)
);

-- Create the memories table
CREATE TABLE memories (
    memory_id INTEGER PRIMARY KEY AUTOINCREMENT,
    trip_id INTEGER NOT NULL,
    memory_text TEXT NOT NULL,
    FOREIGN KEY (trip_id) REFERENCES trips(trip_id)
);

-- Create the memory_photo table
CREATE TABLE memory_photo (
    memory_id INTEGER NOT NULL,
    photo_id INTEGER NOT NULL,
    PRIMARY KEY (memory_id, photo_id),
    FOREIGN KEY (memory_id) REFERENCES memories(memory_id),
    FOREIGN KEY (photo_id) REFERENCES photos(photo_id)
);

